
package vista;

import controlador.*;
import modelo.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class FacturaGUI extends JFrame{
    private JTextField txtCliente, txtProducto, txtCantidad, txtPrecio;
    private JComboBox<String> comboCategoria;
    private JTextArea areaFactura;
    private List<Producto> productos = new ArrayList<>();
    private List<Categoria> ListaCategorias;
    private CategoriaDAO categoriaDAO = new CategoriaDAO();
    private FacturaDAO facturaDAO = new FacturaDAO();
    private ProductoDAO productoDAO = new ProductoDAO();
    
    public FacturaGUI(){
        setTitle("Sistema de facturacion");
        setSize(600,600);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel lblCliente = new JLabel("Cliente: ");
        lblCliente.setBounds(20,20,100,25);
        add(lblCliente);
        
        txtCliente = new JTextField();
        txtCliente.setBounds(120,20,200,25);
        add(txtCliente);
        
        JLabel lblProducto = new JLabel("Producto: ");
        lblProducto.setBounds(20,60,100,25);
        add(lblProducto);
        
        txtProducto = new JTextField();
        txtProducto.setBounds(120,60,200,25);
        add(txtProducto);
        
        JLabel lblCantidad = new JLabel("Cantidad: ");
        lblCantidad.setBounds(20,100,100,25);
        add(lblCantidad);
        
        txtCantidad = new JTextField();
        txtCantidad.setBounds(120,100,200,25);
        add(txtCantidad);
        
        JLabel lblPrecio = new JLabel("Precio: ");
        lblPrecio.setBounds(20,140,100,25);
        add(lblPrecio);
        
        txtPrecio = new JTextField();
        txtPrecio.setBounds(120,140,200,25);
        add(txtPrecio);
        
        JLabel lblCategoria = new JLabel("Categoria:");
        lblCategoria.setBounds(20,180,100,25);
        add(lblCategoria);
        
        comboCategoria = new JComboBox<>();
        comboCategoria.setBounds(120,180,200,25);
        add(comboCategoria);
        
        JButton btnAgregar = new JButton("Agregar Producto");
        btnAgregar.setBounds(20,220,150,30);
        add(btnAgregar);
        
        JButton btnGenerar = new JButton("Generar Factura");
        btnGenerar.setBounds(180,220,150,30);
        add(btnGenerar);
        
        JButton btnLimpiar = new JButton("Nueva factura");
        btnLimpiar.setBounds(340,220,150,30);
        add(btnLimpiar);
        
        areaFactura = new JTextArea();
        JScrollPane scroll = new JScrollPane(areaFactura);
        scroll.setBounds(20,20,540,270);
        add(scroll);
        
         //Cargar categorias
        ListaCategorias=categoriaDAO.obtenerCategorias();
        for(Categoria c: ListaCategorias){
        comboCategoria.addItem(c.getNombre());
        }
        btnAgregar.addActionListener(e-> agregarProducto());
        btnGenerar.addActionListener(e->generarFactura());
        btnLimpiar.addActionListener(e->limpiarFormulario());
   }
    
     private void agregarProducto(){
        try{
            String nombre=txtProducto.getText().trim();
            int cantidad= Integer.parseInt(txtCantidad.getText().trim());
            double precio= Double.parseDouble(txtPrecio.getText().trim());
            int catIndex=comboCategoria.getSelectedIndex();
                    if(nombre.isEmpty()||cantidad<=0||precio<=0||catIndex<0){
            JOptionPane.showMessageDialog(this, "Complete todos los campos correctamente");
            return;
        }
                    Categoria categoria=ListaCategorias.get(catIndex);
                    Producto producto = new Producto(0, nombre, cantidad, precio, categoria);
                    int idGenerado=productoDAO.insertarProducto(producto);
                    
                    producto =new Producto(idGenerado, nombre, cantidad, precio, categoria);
                    productos.add(producto);
                    
                    JOptionPane.showMessageDialog(this, "Producto agregado");
                    txtProducto.setText("");
                    txtCantidad.setText("");
                    txtPrecio.setText("");
                    
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados");
        }
    }
    private void generarFactura(){
        String cliente=txtCliente.getText().trim();
        if(cliente.isEmpty()||productos.isEmpty()){
            JOptionPane.showMessageDialog(this, "Ingrese el nombre del cliente y agregue productos");
            return;
        }
        int facturaId=facturaDAO.insertarFactura(cliente);
        facturaDAO.insertarDetalle(facturaId, productos);
        Factura factura= new Factura(facturaId, cliente, productos);
        StringBuilder sb= new StringBuilder("Factura para: "+cliente+"\n\n");
        for(Producto p: productos){
            sb.append("- ").append(p.getNombre()).append(" (").append(p.getCategoria().getNombre()).append("), Cantidad: ").append(p.getCantidad()).append(", Subtotal c/desc: $").append(String.format("%.2f", p.getSubtotalConDescuento())).append("\n");
        }
        sb.append("\n Subtotal: $").append(String.format("%.2f", factura.calcularSubtotal()));
        sb.append("\n IVA(15%): $").append(String.format("%.2f",factura.calcularIva()));
        sb.append("\n Total: $").append(String.format("%.2f",factura.calcularTotal()));
        areaFactura.setText(sb.toString());
        
    }
    private void limpiarFormulario(){
        txtCliente.setText("");
        txtProducto.setText("");
        txtCantidad.setText("");
        txtPrecio.setText("");
        comboCategoria.setSelectedIndex(0);
        areaFactura.setText("");
        productos.clear();
        
    }
    public static void main(String [] args){
        SwingUtilities.invokeLater(() -> {
        FacturaGUI gui=new FacturaGUI();
        gui.setVisible(true);
    });
    }
}
