
package controlador;
import modelo.*;
//import java.sql.*; → importa todas las clases necesarias para trabajar con JDBC (Connection, PreparedStatement, ResultSet, etc.).
import java.sql.*;

public class ProductoDAO {
    //Método público que recibe un objeto Producto y lo inserta en la base de datos.
//Retorna un int que es el ID autogenerado del producto (o -1 si hay error).
    public int insertarProducto(Producto producto){
        //Consulta SQL preparada para insertar datos en la tabla producto.
        //Se usan ? como marcadores de posición para evitar inyección SQL y facilitar el seteo de parámetros.
        String sql="INSERT INTO producto (nombre, cantidad, precio_unitario, categoria_id) VALUES(?, ?, ?, ?)";
        //Se abre una conexión a MySQL usando tu clase ConeccionBD.
        //Se crea un PreparedStatement para la consulta sql.
        //Statement.RETURN_GENERATED_KEYS → indica que queremos recuperar el ID autogenerado por MySQL.
        try(Connection conn= ConeccionBD.conectar();
               PreparedStatement ps=conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
            //setString(1, ...) → reemplaza el primer ? por el nombre del producto.
            //setInt(2, ...) → segundo ? por la cantidad.
            //setDouble(3, ...) → tercer ? por el precio unitario.
            //setInt(4, ...) → cuarto ? por el ID de la categoría (que viene de producto.getCategoria().getId()).
            ps.setString(1, producto.getNombre());
            ps.setInt(2, producto.getCantidad());
            ps.setDouble(3, producto.getPrecioUnitario());
            ps.setInt(4, producto.getCategoria().getId());
            //Ejecuta la inserción en la base de datos.
            //Devuelve un número entero con la cantidad de filas afectadas (aquí no lo guardas porque no lo necesitas).
            ps.executeUpdate();
            //getGeneratedKeys() devuelve un ResultSet con las claves generadas automáticamente (por ejemplo, el campo id_producto autoincremental).
            //Si hay un resultado (rs.next()), devuelve el primer valor (rs.getInt(1)), que es el ID recién creado.
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()){
                return rs.getInt(1);//ID generado
            }
        }catch (SQLException e){
            System.out.println("Errror al insertar producto: "+e.getMessage());
    }
        return -1;
}
}
