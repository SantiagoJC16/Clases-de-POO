
package modelo;

import java.sql.Connection;
import modelo.ConeccionBD;
public class ComporbacionConeccion {
    
    public static void main(String[] args){
        Connection conn = ConeccionBD.conectar();
        if(conn != null){
            System.out.println("Coneccion exitosa ");
        }else{
            System.out.println("Fallo la coneccion");
        }
    }
}
