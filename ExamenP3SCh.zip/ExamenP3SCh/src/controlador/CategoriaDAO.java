
package controlador;

//modelo.* → importa las clases del modelo (Categoria, ConeccionBD, etc.).
//java.sql.* → para trabajar con JDBC (Connection, Statement, ResultSet).
//java.util.* → para usar List y ArrayList.


import modelo.*;
import java.sql.*;
import java.util.*;
public class CategoriaDAO {
    //Método público que devuelve una lista de objetos Categoria.
//Inicializa un ArrayList vacío donde se guardarán las categorías.
    public List<Categoria> obtenerCategorias(){
      
        List<Categoria> lista=new ArrayList<>();
          // Consulta para obtener todas las columnas de la tabla categoria.
        String sql= "SELECT * FROM categoria";
        
       // Se conecta a la base de datos con ConeccionBD.
//Se crea un Statement simple (no preparado) para ejecutar la consulta.
//executeQuery(sql) devuelve un ResultSet con todas las filas de la tabla categoria.
        try(Connection conn= ConeccionBD.conectar();
             
            Statement stmt=conn.createStatement();
                
            ResultSet rs=stmt.executeQuery(sql)){
            //rs.next() → avanza fila por fila en el ResultSet.
//Por cada fila:
//Se crea un objeto Categoria con id, nombre y descuento.
//Se agrega el objeto a la lista lista.
            while(rs.next()){
                Categoria cat= new Categoria(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getDouble("descuento")
                );
                lista.add(cat);
            } 
        }catch (SQLException e){
            System.out.println("Error al obtener categorias: "+e.getMessage());
            
        }
        //Devuelve la lista de categorías obtenida de la base de datos.
//Si ocurre un error, devuelve una lista vacía.
        return lista;
    }
    
}
