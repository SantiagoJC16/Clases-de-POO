
//Connection → interfaz que representa la conexión activa con la base de datos.
//DriverManager → clase que maneja los drivers JDBC y permite obtener una conexión.
//SQLException → excepción que se lanza si ocurre un error al trabajar con la base de datos.
package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConeccionBD {
    
    private static final String URL = "jdbc:mysql://localhost:3306/proyecto_facturacion";
    private static final String USER = "root";
    private static final String PASSWORD = "Santiago@20";
    
    //Método estático para poder llamarlo sin crear un objeto de ConeccionBD.
//Devuelve un Connection ya listo para usar.
    public static Connection conectar(){
        try{
            return DriverManager.getConnection(URL,USER,PASSWORD);
            //Intenta establecer la conexión usando los datos definidos (URL, USER, PASSWORD).
            //Si la conexión es correcta, devuelve el objeto Connection.
        }catch(SQLException e){
            System.out.println("Error al conectar a la base de datos :"+e.getMessage());
            return null;
        }
    }
}
