
package Modelo;


public class Producto {
    private String nombre;
    private int cantidad;
    private double precioUnitario;
    private Categoria categoria;

    public Producto(String nombre, int cantidad, double precioUnitario, Categoria categoria) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }
    public int getCantidad() {
        return cantidad;
    }
    public double getPrecioUnitario() {
        return precioUnitario;
    }
    public Categoria getCategoria() {
        return categoria;
    }
    
    public double getSubtotalConDescuento(){
        double subtotal=cantidad*precioUnitario;
        return subtotal-(subtotal*categoria.getDescuento()/100);
    }
}
