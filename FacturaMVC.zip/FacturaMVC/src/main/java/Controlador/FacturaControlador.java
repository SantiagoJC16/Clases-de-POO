
package Controlador;

import Modelo.*;
import java.util.HashMap;

public class FacturaControlador {
   private Factura factura;
    private HashMap<String, Categoria> categorias;
    public FacturaControlador(String cliente){
    factura=new Factura(cliente);
    categorias=new HashMap<>();
    cargarCategorias();
    }
    private void cargarCategorias(){
        categorias.put("Tecnologia", new Categoria("Tecnologia", 10));
        categorias.put("Alimentos", new Categoria("Alimentos", 5));
        categorias.put("Ropa", new Categoria("Ropa", 15));
    }
    public HashMap<String, Categoria> getCategorias(){
        return categorias;
    }
    public void agregarProducto(String nombre, int cantidad, double precio, String nombreCategoria){
        Categoria categoria=categorias.get(nombreCategoria);
        if(categoria!=null &&cantidad>0&&precio>=0){
            Producto producto=new Producto(nombre, cantidad, precio, categoria);
            factura.agregarProducto(producto);
        }
    }
    public void eliminarUltimoProducto(){
        if(!factura.getProductos().isEmpty()){
            factura.eliminarProducto(factura.getProductos().size()-1);
        }
    }
    public void limpiarFactura(String nuevoCliente){
        factura=new Factura(nuevoCliente);
    }
    public String generarFactura(){
        return factura.generarFactura();
    }
}
