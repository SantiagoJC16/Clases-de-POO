
package mongodemo;
import com.mongodb.client.*;
import org.bson.Document;


public class MongoAtlasUsersDemo {
    
    private static final String URI = "mongodb+srv://sxchafla:SantiagoXC20@@cluster0.gydjlnn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    
    public static FindIterable<Document> getUsers(){
        MongoClient client = MongoClients.create(URI);
        MongoDatabase db = client.getDatabase("sample_mflix");
        MongoCollection<Document> users = db.getCollection("users");
        return users.find();
        
    }


    
}
