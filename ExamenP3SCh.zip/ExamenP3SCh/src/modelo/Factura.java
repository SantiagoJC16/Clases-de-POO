
package modelo;

import java.util.List;
public class Factura {
    private int id;
    private String cliente;
    private List<Producto> productos;

    public Factura(int id, String cliente, List<Producto> productos) {
        this.id = id;
        this.cliente = cliente;
        this.productos = productos;
    }

    public int getId() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public List<Producto> getProductos() {
        return productos;
    }
    
    public double calcularSubtotal(){
        return productos.stream().mapToDouble(Producto::getSubtotalConDescuento).sum();
    }
    public double calcularIva(){
        return calcularSubtotal() * 0.15;
    }
    public double calcularTotal(){
        return calcularSubtotal() + calcularIva();
    }
    
}
