
package controlador;
//List → se usa para manejar la lista de productos de una factura.
//modelo.* → importa Producto, ConeccionBD, etc.
//java.sql.* → para trabajar con JDBC.
import java.util.List;
import modelo.*;
import java.sql.*;
public class FacturaDAO {
    public int insertarFactura(String cliente){
        //Método público que inserta una nueva factura en la tabla factura.
//Recibe como parámetro el nombre del cliente.
//La consulta usa ? como marcador para evitar inyección SQL.


        String sql="INSERT INTO factura(cliente) VALUES(?)";
       // Se conecta a la base de datos usando ConeccionBD.
//Statement.RETURN_GENERATED_KEYS → para recuperar el ID autogenerado de la factura.
        try(Connection conn= ConeccionBD.conectar();
                //ps.setString(1, cliente) → reemplaza el ? por el nombre del cliente.
//executeUpdate() → ejecuta la inserción.
//getGeneratedKeys() → obtiene el ID generado automáticamente por la base de datos.
//i hay un resultado (rs.next()), devuelve ese ID de factura.
                PreparedStatement ps= conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
                ps.setString(1, cliente);
                ps.executeUpdate();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()){
                    return rs.getInt(1);
                }
                
    }catch(SQLException e){
        System.out.println("ERror al insertar factura:"+e.getMessage());
    }
        return -1;
    }
    //Inserta los detalles de la factura (productos y cantidades) en la tabla detalle_factura.
//Recibe:
//facturaId → ID de la factura principal.
//productos → lista de objetos Producto que contiene id y cantidad.
    public void insertarDetalle(int facturaId, List<Producto> productos){
    String sql= "INSERT INTO detalle_factura(factura_id, producto_id, cantidad) VALUES (?,?,?)";
    try(Connection conn=ConeccionBD.conectar();
           // Se crea un PreparedStatement para la inserción.

//Para cada producto:
//Se asigna el ID de la factura.
//Se asigna el ID del producto.
//Se asigna la cantidad.
//addBatch() → agrega la inserción al batch para ejecutar todas juntas.
//executeBatch() → ejecuta todas las inserciones de la lista de productos de una sola vez.
            PreparedStatement ps=conn.prepareStatement(sql)){
        for(Producto p: productos){
            ps.setInt(1, facturaId);
            ps.setInt(2, p.getId());
            ps.setInt(3, p.getCantidad());
            ps.addBatch();
        }
        ps.executeBatch();
}catch(SQLException e){
    System.out.println("Error al insertar detalle: "+e.getMessage());
}
    }
}
