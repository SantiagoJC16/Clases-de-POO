
package controlador;

import modelo.*;
import java.sql.*;
import java.util.*;
public class CategoriaDAO {
    public List<Categoria> obtenerCategorias(){
        List<Categoria> lista=new ArrayList<>();
        
        String sql= "SELECT * FROM categoria";
        
        try(Connection conn= ConeccionBD.conectar();
             
            Statement stmt=conn.createStatement();
                
            ResultSet rs=stmt.executeQuery(sql)){
            while(rs.next()){
                Categoria cat= new Categoria(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getDouble("descuento")
                );
                lista.add(cat);
            } 
        }catch (SQLException e){
            System.out.println("Error al obtener categorias: "+e.getMessage());
            
        }
        return lista;
    }
    
}
