
package Modelo;


public class Categoria {
     private String nombre;
    private double descuento;

    public Categoria(String nombre, double descuento) {
        this.nombre = nombre;
        this.descuento = descuento;
    }
    public String getNombre(){return nombre;}
    public double getDescuento(){return descuento;}
    
    
         
    
}
