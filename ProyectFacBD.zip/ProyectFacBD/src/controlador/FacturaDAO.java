
package controlador;

import java.util.List;
import modelo.*;
import java.sql.*;
public class FacturaDAO {
    public int insertarFactura(String cliente){
        String sql="INSERT INTO factura(cliente) VALUES(?)";
        try(Connection conn= ConeccionBD.conectar();
                PreparedStatement ps= conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
                ps.setString(1, cliente);
                ps.executeUpdate();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()){
                    return rs.getInt(1);
                }
                
    }catch(SQLException e){
        System.out.println("ERror al insertar factura:"+e.getMessage());
    }
        return -1;
    }
    public void insertarDetalle(int facturaId, List<Producto> productos){
    String sql= "INSERT INTO detalle_factura(factura_id, producto_id, cantidad) VALUES (?,?,?)";
    try(Connection conn=ConeccionBD.conectar();
            PreparedStatement ps=conn.prepareStatement(sql)){
        for(Producto p: productos){
            ps.setInt(1, facturaId);
            ps.setInt(2, p.getId());
            ps.setInt(3, p.getCantidad());
            ps.addBatch();
        }
        ps.executeBatch();
}catch(SQLException e){
    System.out.println("Error al insertar detalle: "+e.getMessage());
}
    }
}
