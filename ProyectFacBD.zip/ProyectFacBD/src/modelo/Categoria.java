
package modelo;


public class Categoria {
    private int id;
    private String nombre;
    private double descuento;

    public Categoria(int id, String nombre, double descuento) {
        this.id = id;
        this.nombre = nombre;
        this.descuento = descuento;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getDescuento() {
        return descuento;
    }
    
    
}
