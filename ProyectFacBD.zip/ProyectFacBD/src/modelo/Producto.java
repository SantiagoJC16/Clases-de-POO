
package modelo;


public class Producto {
    private int id;
    private String nombre;
    private int cantidad;
    private double precioUnitario;
    private Categoria categoria;

    public Producto(int id, String nombre, int cantidad, double precioUnitario, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.categoria = categoria;
        this.cantidad = cantidad;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCantidad() {
        return cantidad;
    }
    
    public double getSubtotalConDescuento(){
        double subtotal = cantidad * precioUnitario;
        return subtotal - (subtotal * categoria.getDescuento()/100);
    }
}
