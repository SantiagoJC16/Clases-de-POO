
package modelo;


public class DetalleFactura {
    private int id;
    private int facturaId;
    private Producto producto;
    private int cantidad;

    public DetalleFactura(int id, int facturaId, Producto producto, int cantidad) {
        this.id = id;
        this.facturaId = facturaId;
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public int getId() {
        return id;
    }

    public int getFacturaId() {
        return facturaId;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }
    

    
}
