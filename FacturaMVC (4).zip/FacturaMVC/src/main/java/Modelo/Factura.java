
package Modelo;
import java.util.ArrayList;
import java.util.List;

public class Factura {
    
    private String cliente;
    private List<Producto> productos;
   

    public Factura(String cliente) {
        this.cliente = cliente;
        this.productos = new ArrayList<>();
        
        
    }

    public List<Producto> getProductos() {
        return productos;
    }
    
    public void agregarProducto(Producto producto){
        productos.add(producto);
    }
    public void eliminarProducto(int index){
        if (index>=0&&index<productos.size()){
            productos.remove(index);
        }
    }
    public double calcularSubtotal(){
        return productos.stream()
                .mapToDouble(Producto::getSubtotalConDescuento)
                .sum();
    }
    public double calcularIVA(){
        return calcularSubtotal()*0.15;
    }
    public double calcularTotal(){
        return calcularSubtotal()+calcularIVA();
        
    }
 
   
    public String generarFactura(){
        StringBuilder sb=new StringBuilder("Cliente: "+cliente+"\n Productos:");
        for (Producto p:productos){
            sb.append("- ").append(p.getNombre())
               .append(" (").append(p.getCategoria().getNombre()).append(")")
                    .append(",\n Cant:").append(p.getCantidad())
                    .append(",\n Precio: $").append(p.getPrecioUnitario())
                    .append(",\n Subtotal c/desc: $").append(p.getSubtotalConDescuento()).append(".");
                    }
        sb.append("\n Subtotal: $").append(calcularSubtotal());
        sb.append("\n IVA (15%): $").append(calcularIVA());
        sb.append("\n Total: $").append(calcularTotal());
        
        
        return sb.toString();  
    }
    
    
    
    
    
}

