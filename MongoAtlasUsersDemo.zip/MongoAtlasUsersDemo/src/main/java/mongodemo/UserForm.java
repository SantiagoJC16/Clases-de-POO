
package mongodemo;
import com.mongodb.client.*;
import javax.swing.JTable;
import org.bson.Document;
import javax.swing.table.DefaultTableModel;

public class UserForm extends javax.swing.JFrame {
    
        public UserForm() {
        initComponents();
        }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();  // ✅ Usamos la que ya declaraste arriba

        btnLoadUsers = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Demo Usuarios MongoDB Atlas");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"_id", "Nombre", "Email"}
        ));
        jScrollPane1.setViewportView(jTable1);

        btnLoadUsers.setText("Cargar Usuarios");
        btnLoadUsers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadUsersActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnLoadUsers)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnLoadUsers)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }

    private void btnLoadUsersActionPerformed(java.awt.event.ActionEvent evt) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("_id");
        model.addColumn("Nombre");
        model.addColumn("Email");

        for (Document doc : MongoAtlasUsersDemo.getUsers()) {
            model.addRow(new Object[]{
                doc.getObjectId("_id").toString(),
                doc.getString("name"),
                doc.getString("email")
            });
        }
        jTable1.setModel(model);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserForm().setVisible(true);
            }
        });
    }

    private javax.swing.JButton btnLoadUsers;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    }

